import UIKit

var overallPlayerScore = 501
var scoreForEachRound = 0

// 3 rounds
// 1st round
scoreForEachRound = 10 * 3
overallPlayerScore -= scoreForEachRound
print("You're not very good at this game, are you?")
// 2nd round
scoreForEachRound = 15 * 3
overallPlayerScore -= scoreForEachRound
print("This is just a fluke!")
//3rd round
scoreForEachRound = 50 * 3
overallPlayerScore -= scoreForEachRound
print("How is this even possible?!")




