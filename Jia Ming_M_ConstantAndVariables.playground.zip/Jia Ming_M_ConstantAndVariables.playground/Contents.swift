import UIKit

let eggs = "Eggs"
let milk = "Milk"
let cheese = "Cheese"
let bread = "Bread"
let rice = "Rice"
let newLine = "\n"

let list = eggs + newLine + milk + newLine + cheese + newLine + bread + newLine + rice
print(list)
